This project is a simple dungeon-crawling game written in Haskell.

You can download the Haskell platform (compiler and libraries) at http://www.haskell.org/platform/

To build and run the project after cloning the repository, open a terminal in the project folder and do:

    $ cabal configure && cabal build
    $ ./dist/build/haskell-game/haskell-game

Use the I, J, K, and L keys to move the player. Ctrl-C quits the game.
